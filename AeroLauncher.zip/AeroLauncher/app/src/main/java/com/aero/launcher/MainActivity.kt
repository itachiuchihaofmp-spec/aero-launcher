package com.aero.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.WallpaperManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doOnTextChanged
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

private const val COLS = 4
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val WHITE = Color.WHITE

private class Cell(val box: LinearLayout, val img: ImageView, val label: TextView?)
private class CellHolder(val cell: Cell) : RecyclerView.ViewHolder(cell.box)
private class RowVH(val row: LinearLayout, val icon: ImageView, val text: TextView) :
    RecyclerView.ViewHolder(row)

private fun Context.dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

private fun Context.shape(color: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color)
    cornerRadius = dp(radius).toFloat()
    if (stroke != 0) setStroke(dp(1), stroke)
}

/** iOS-like spring: quick press-in, bouncy release. */
private fun View.spring(to: Float, bouncy: Boolean) {
    for (p in listOf(DynamicAnimation.SCALE_X, DynamicAnimation.SCALE_Y)) {
        SpringAnimation(this, p, to).apply {
            spring.setStiffness(if (bouncy) 380f else 700f).setDampingRatio(if (bouncy) 0.42f else 0.8f)
            start()
        }
    }
}

private fun View.pressFx() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.spring(0.86f, false)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.spring(1f, true)
        }
        false
    }
}

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var root: Root
    private lateinit var pager: ViewPager2
    private lateinit var dockBar: LinearLayout
    private lateinit var dotsBar: LinearLayout
    private lateinit var scrim: View
    private lateinit var spot: LinearLayout
    private lateinit var field: EditText
    private lateinit var results: RecyclerView
    private var libScroll: ScrollView? = null

    private val pool = RecyclerView.RecycledViewPool()
    private val pagesAdapter = PagesAdapter()
    private val resultAdapter = ResultAdapter()
    private val bg = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val wm by lazy { WallpaperManager.getInstance(this) }
    private val imm by lazy { getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager }

    private var apps = emptyList<App>()
    private var libApps = emptyList<App>()
    private var dockApps = emptyList<App>()
    private var pages: List<List<Any>> = listOf(listOf(Header))
    private var rows = 5
    private var topInset = 0
    private var searchOpen = false

    private val pkgRefresh = Runnable { refresh() }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            handler.removeCallbacks(pkgRefresh)
            handler.postDelayed(pkgRefresh, 400)
        }
    }

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        IconLoader.px = dp(58)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val dm = resources.displayMetrics
        rows = ((dm.heightPixels / dm.density - 232) / 92).toInt().coerceIn(3, 6)
        buildUi()
        setContentView(root)
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
        refresh()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (searchOpen) closeSearch()
        if (::pager.isInitialized) pager.setCurrentItem(0, true)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            searchOpen -> closeSearch()
            pager.currentItem != 0 -> pager.setCurrentItem(0, true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(pkgReceiver)
        handler.removeCallbacksAndMessages(null)
    }

    // ───────────────────────── root + gestures ─────────────────────────

    private inner class Root(ctx: Context) : FrameLayout(ctx) {
        private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || searchOpen) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (abs(dy) < dp(70) || abs(dy) < abs(dx) * 1.5f || abs(vy) < 700) return false
                val onLib = pager.currentItem == pages.size
                val libTop = (libScroll?.scrollY ?: 0) == 0
                if (dy > 0 && e1.y > topInset + dp(24) && (!onLib || libTop)) openSearch()
                else if (dy < 0 && !onLib) pager.setCurrentItem(pages.size, true)
                return false
            }
        })

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            gd.onTouchEvent(ev)
            return super.dispatchTouchEvent(ev)
        }
    }

    // ───────────────────────── UI construction ─────────────────────────

    private fun buildUi() {
        root = Root(this)

        scrim = View(this).apply { setBackgroundColor(0x80000000.toInt()); alpha = 0f }
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        pager = ViewPager2(this).apply {
            adapter = pagesAdapter
            offscreenPageLimit = 1
            (getChildAt(0) as RecyclerView).overScrollMode = View.OVER_SCROLL_NEVER
            setPageTransformer { page, pos ->
                val a = abs(pos).coerceAtMost(1f)
                page.alpha = 1f - 0.6f * a
                page.scaleX = 1f - 0.1f * a
                page.scaleY = 1f - 0.1f * a
            }
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageScrolled(position: Int, offset: Float, px: Int) =
                    onScroll(position, offset)
            })
        }
        root.addView(pager, FrameLayout.LayoutParams(MATCH, MATCH))

        dotsBar = LinearLayout(this).apply { gravity = Gravity.CENTER }
        root.addView(
            dotsBar,
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        )

        dockBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = shape(0x38FFFFFF, 30, 0x40FFFFFF)
            setPadding(dp(8), 0, dp(8), 0)
        }
        root.addView(
            dockBar,
            FrameLayout.LayoutParams(MATCH, dp(84), Gravity.BOTTOM).apply {
                leftMargin = dp(14); rightMargin = dp(14)
            }
        )

        buildSearch()
        root.addView(spot, FrameLayout.LayoutParams(MATCH, MATCH))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            layoutBars(b.top, b.bottom)
            ins
        }
    }

    private fun layoutBars(top: Int, bottom: Int) {
        topInset = top
        (pager.layoutParams as FrameLayout.LayoutParams).apply {
            topMargin = top; bottomMargin = bottom + dp(122)
        }
        (dockBar.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottom + dp(12)
        (dotsBar.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottom + dp(104)
        spot.setPadding(0, top, 0, 0)
        root.requestLayout()
    }

    /** Called continuously while swiping: dots, library scrim, dock fade, wallpaper parallax. */
    private fun onScroll(position: Int, offset: Float) {
        val n = pages.size + 1
        val p = position + offset
        for (i in 0 until dotsBar.childCount) {
            val a = (1f - abs(i - p)).coerceIn(0.35f, 1f)
            dotsBar.getChildAt(i).apply { alpha = a; scaleX = 0.7f + 0.5f * a; scaleY = 0.7f + 0.5f * a }
        }
        val f = (p - (n - 2)).coerceIn(0f, 1f)
        scrim.alpha = f
        dockBar.alpha = 1f - f
        dockBar.translationY = f * dp(30)
        dockBar.visibility = if (f >= 1f) View.INVISIBLE else View.VISIBLE
        try {
            root.windowToken?.let { wm.setWallpaperOffsets(it, p / max(1, n - 1), 0.5f) }
        } catch (e: Exception) {
        }
    }

    private fun buildDots() {
        dotsBar.removeAllViews()
        val n = pages.size + 1
        repeat(n) {
            dotsBar.addView(
                View(this).apply { background = shape(WHITE, 4) },
                LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) }
            )
        }
        try {
            wm.setWallpaperOffsetSteps(1f / max(1, n - 1), 1f)
        } catch (e: Exception) {
        }
        onScroll(pager.currentItem, 0f)
    }

    // ───────────────────────── data ─────────────────────────

    private fun loadApps(): List<App> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { ri ->
                App(
                    ri.loadLabel(packageManager).toString(),
                    ri.activityInfo.packageName,
                    ri.activityInfo.name,
                    if (Build.VERSION.SDK_INT >= 26) ri.activityInfo.applicationInfo.category else -1
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun defaultDock(all: List<App>): List<String> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        return intents
            .mapNotNull {
                packageManager.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            }
            .mapNotNull { p -> all.firstOrNull { it.pkg == p }?.key }
            .distinct()
    }

    private fun refresh() {
        bg.execute {
            val all = loadApps()
            if (!store.hasDock && all.isNotEmpty()) store.dock = defaultDock(all)
            runOnUiThread { show(all) }
        }
    }

    private fun show(all: List<App>) {
        apps = all
        val hidden = store.hidden
        val visible = all.filter { it.key !in hidden }
        dockApps = store.dock.mapNotNull { k -> all.firstOrNull { it.key == k } }.take(4)
        val dockKeys = dockApps.map { it.key }.toSet()
        libApps = visible
        val grid = visible.filter { it.key !in dockKeys }
        val first = (rows - 1) * COLS
        val list = ArrayList<List<Any>>()
        list.add(listOf<Any>(Header) + grid.take(first))
        grid.drop(first).chunked(rows * COLS).forEach { list.add(it) }
        pages = list
        IconLoader.warm(this, visible + dockApps)
        renderDock()
        pagesAdapter.notifyDataSetChanged()
        buildDots()
    }

    private fun topApps(n: Int): List<App> {
        val c = store.counts()
        return libApps.filter { (c[it.key] ?: 0) > 0 }.sortedByDescending { c[it.key] ?: 0 }.take(n)
    }

    private fun launch(app: App, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val o = from?.let {
                ActivityOptions.makeScaleUpAnimation(it, 0, 0, it.width, it.height).toBundle()
            }
            startActivity(i, o)
            store.bump(app.key)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────────────────── icon cells ─────────────────────────

    private fun newCell(labels: Boolean): Cell {
        val img = ImageView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            pressFx()
        }
        box.addView(img, LinearLayout.LayoutParams(dp(58), dp(58)))
        var tv: TextView? = null
        if (labels) {
            tv = TextView(this).apply {
                setTextColor(WHITE)
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setShadowLayer(5f, 0f, 1f, 0x99000000.toInt())
                setPadding(dp(2), 0, dp(2), 0)
            }
            box.addView(tv, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        }
        return Cell(box, img, tv)
    }

    private fun Cell.bind(app: App) {
        label?.text = app.label
        IconLoader.load(img, app)
        box.setOnClickListener { launch(app, img) }
        box.setOnLongClickListener { showMenu(app, img); true }
    }

    private fun renderDock() {
        dockBar.removeAllViews()
        for (a in dockApps) {
            val c = newCell(false)
            c.box.gravity = Gravity.CENTER
            c.bind(a)
            dockBar.addView(c.box, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun clockView(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        layoutParams = RecyclerView.LayoutParams(MATCH, dp(116))
        setPadding(0, dp(6), 0, 0)
        addView(TextClock(context).apply {
            format12Hour = "h:mm"
            format24Hour = "H:mm"
            textSize = 64f
            setTextColor(WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(10f, 0f, 2f, 0x55000000)
        })
        addView(TextClock(context).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 15f
            setTextColor(0xE6FFFFFF.toInt())
            setShadowLayer(6f, 0f, 1f, 0x55000000)
        })
    }

    // ───────────────────────── long-press menu ─────────────────────────

    private fun showMenu(app: App, anchor: View) {
        anchor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xF2262629.toInt(), 16)
            setPadding(0, dp(6), 0, dp(6))
            elevation = dp(10).toFloat()
        }
        val pw = PopupWindow(col, dp(210), WRAP, true)
        pw.setBackgroundDrawable(ColorDrawable(0))

        fun row(t: String, color: Int = WHITE, act: () -> Unit) {
            col.addView(TextView(this).apply {
                text = t
                textSize = 15f
                setTextColor(color)
                setPadding(dp(18), dp(12), dp(18), dp(12))
                setOnClickListener { pw.dismiss(); act() }
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val inDock = app.key in store.dock
        val isHidden = app.key in store.hidden
        row(if (inDock) "Remove from Dock" else "Add to Dock") {
            val d = store.dock.toMutableList()
            if (!d.remove(app.key)) {
                if (d.size >= 4) d.removeAt(d.size - 1)
                d.add(app.key)
            }
            store.dock = d
            refresh()
        }
        row(if (isHidden) "Unhide" else "Hide from Home") {
            store.hidden = if (isHidden) store.hidden - app.key else store.hidden + app.key
            refresh()
        }
        row("App info") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
        row("Uninstall", 0xFFFF453A.toInt()) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        }

        col.alpha = 0f; col.scaleX = 0.85f; col.scaleY = 0.85f
        pw.showAsDropDown(anchor, (anchor.width - dp(210)) / 2, 0)
        col.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(140).start()
    }

    // ───────────────────────── pager pages ─────────────────────────

    private inner class PagesAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pages.size + 1
        override fun getItemViewType(position: Int) = if (position == pages.size) 1 else 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val v: View = if (viewType == 1) {
                FrameLayout(this@MainActivity)
            } else {
                RecyclerView(this@MainActivity).apply {
                    layoutManager = object : GridLayoutManager(this@MainActivity, COLS) {
                        override fun canScrollVertically() = false
                    }
                    setRecycledViewPool(pool)
                    itemAnimator = null
                    overScrollMode = View.OVER_SCROLL_NEVER
                    isNestedScrollingEnabled = false
                    setPadding(dp(14), dp(4), dp(14), 0)
                }
            }
            v.layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(v) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val v = holder.itemView
            if (v is RecyclerView) {
                val items = pages[position]
                (v.layoutManager as GridLayoutManager).spanSizeLookup =
                    object : GridLayoutManager.SpanSizeLookup() {
                        override fun getSpanSize(i: Int) = if (items[i] === Header) COLS else 1
                    }
                v.adapter = GridAdapter(items)
            } else if (v is FrameLayout) {
                v.removeAllViews()
                v.addView(buildLibrary())
            }
        }
    }

    private inner class GridAdapter(val items: List<Any>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = items.size
        override fun getItemViewType(position: Int) = if (items[position] === Header) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            if (viewType == 0) return object : RecyclerView.ViewHolder(clockView()) {}
            val c = newCell(true)
            c.box.layoutParams = RecyclerView.LayoutParams(MATCH, dp(92))
            c.box.setPadding(0, dp(8), 0, 0)
            return CellHolder(c)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is CellHolder) holder.cell.bind(items[position] as App)
        }
    }

    // ───────────────────────── App Library ─────────────────────────

    private fun groupOf(c: Int): String {
        if (Build.VERSION.SDK_INT < 26) return "Utilities"
        return when (c) {
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Entertainment"
            ApplicationInfo.CATEGORY_IMAGE -> "Creativity"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            ApplicationInfo.CATEGORY_NEWS -> "News"
            ApplicationInfo.CATEGORY_MAPS -> "Travel"
            else -> "Utilities"
        }
    }

    private fun buildLibrary(): View {
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            layoutParams = FrameLayout.LayoutParams(MATCH, MATCH)
        }
        libScroll = sv
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(16))
        }
        col.addView(TextView(this).apply {
            text = "App Library"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(WHITE)
            setPadding(dp(6), dp(6), 0, dp(10))
        })
        col.addView(TextView(this).apply {
            text = "Search"
            textSize = 16f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            background = shape(0x33FFFFFF, 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0)
            compoundDrawablePadding = dp(10)
            compoundDrawableTintList = ColorStateList.valueOf(WHITE)
            setOnClickListener { openSearch() }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(6), 0, dp(6), dp(8)) })

        val groups = linkedMapOf<String, MutableList<App>>()
        for (g in listOf("Suggestions", "Social", "Entertainment", "Creativity", "Games",
            "Productivity", "News", "Travel", "Utilities")) groups[g] = mutableListOf()
        groups.getValue("Suggestions").addAll(topApps(4))
        for (a in libApps) groups.getValue(groupOf(a.category)).add(a)

        groups.entries.filter { it.value.isNotEmpty() }.chunked(2).forEach { pair ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { e ->
                line.addView(
                    libCard(e.key, e.value),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
                )
            }
            if (pair.size == 1) line.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
            col.addView(line)
        }
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun libCard(title: String, list: List<App>): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0x33FFFFFF, 24)
            setPadding(dp(12), dp(10), dp(12), dp(12))
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xE6FFFFFF.toInt())
            setPadding(dp(2), 0, 0, dp(8))
        })
        val shown = list.take(4)
        for (r in 0..1) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..1) {
                val idx = r * 2 + c
                val cellBox = FrameLayout(this)
                line.addView(cellBox, LinearLayout.LayoutParams(0, dp(62), 1f))
                if (idx >= shown.size) continue
                if (idx == 3 && list.size > 4) {
                    cellBox.addView(TextView(this).apply {
                        text = "+${list.size - 3}"
                        textSize = 15f
                        gravity = Gravity.CENTER
                        setTextColor(WHITE)
                        background = shape(0x33FFFFFF, 13)
                        setOnClickListener { openSearch() }
                        pressFx()
                    }, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
                } else {
                    val iv = ImageView(this)
                    IconLoader.load(iv, shown[idx])
                    iv.pressFx()
                    iv.setOnClickListener { launch(shown[idx], iv) }
                    iv.setOnLongClickListener { showMenu(shown[idx], iv); true }
                    cellBox.addView(iv, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
                }
            }
            card.addView(line)
        }
        return card
    }

    // ───────────────────────── Spotlight search ─────────────────────────

    private fun buildSearch() {
        spot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            isClickable = true
            setBackgroundColor(0xE6101014.toInt())
            setOnClickListener { closeSearch() }
        }
        field = EditText(this).apply {
            hint = "Search apps or the web"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(WHITE)
            textSize = 17f
            background = shape(0x26FFFFFF, 14)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0)
            compoundDrawablePadding = dp(10)
            compoundDrawableTintList = ColorStateList.valueOf(WHITE)
            doOnTextChanged { t, _, _, _ -> runSearch(t?.toString() ?: "") }
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    when (val first = resultAdapter.items.firstOrNull { it is App || it is Web }) {
                        is App -> { closeSearch(); launch(first, null) }
                        is Web -> { closeSearch(); web(first.q) }
                    }
                    true
                } else false
            }
        }
        results = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = resultAdapter
            itemAnimator = null
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(320))
            addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrollStateChanged(rv: RecyclerView, state: Int) {
                    if (state == RecyclerView.SCROLL_STATE_DRAGGING) hideKb()
                }
            })
        }
        spot.addView(field, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(12), dp(16), dp(4)) })
        spot.addView(results, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun hideKb() = imm.hideSoftInputFromWindow(field.windowToken, 0)

    private fun openSearch() {
        if (searchOpen) return
        searchOpen = true
        field.setText("")
        runSearch("")
        spot.visibility = View.VISIBLE
        spot.alpha = 0f
        spot.translationY = -dp(40).toFloat()
        spot.animate().alpha(1f).translationY(0f).setDuration(220)
            .setInterpolator(DecelerateInterpolator()).start()
        field.requestFocus()
        field.post { imm.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT) }
    }

    private fun closeSearch() {
        if (!searchOpen) return
        searchOpen = false
        hideKb()
        spot.animate().alpha(0f).translationY(-dp(40).toFloat()).setDuration(160)
            .withEndAction { spot.visibility = View.GONE }.start()
    }

    private fun web(q: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        } catch (e: Exception) {
        }
    }

    private fun runSearch(q: String) {
        val t = q.trim()
        val list = ArrayList<Any>()
        if (t.isEmpty()) {
            val top = topApps(6)
            if (top.isNotEmpty()) {
                list.add(Section("Suggested"))
                list.addAll(top)
            }
        } else {
            list.addAll(
                apps.filter { it.label.contains(t, ignoreCase = true) }
                    .sortedWith(compareBy({ !it.label.startsWith(t, ignoreCase = true) }, { it.label.lowercase() }))
            )
            list.add(Web(t))
        }
        resultAdapter.items = list
        resultAdapter.notifyDataSetChanged()
    }

    private inner class ResultAdapter : RecyclerView.Adapter<RowVH>() {
        var items: List<Any> = emptyList()
        override fun getItemCount() = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowVH {
            val icon = ImageView(this@MainActivity)
            val text = TextView(this@MainActivity).apply {
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), dp(8), dp(20), dp(8))
                layoutParams = RecyclerView.LayoutParams(MATCH, WRAP)
                addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
                addView(text, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
            }
            return RowVH(row, icon, text)
        }

        override fun onBindViewHolder(h: RowVH, position: Int) {
            val item = items[position]
            h.icon.visibility = View.VISIBLE
            h.icon.clearColorFilter()
            h.icon.setPadding(0, 0, 0, 0)
            h.text.textSize = 17f
            h.text.typeface = Typeface.DEFAULT
            h.text.setTextColor(WHITE)
            h.row.isClickable = false
            h.row.setOnClickListener(null)
            h.row.setOnLongClickListener(null)
            when (item) {
                is App -> {
                    IconLoader.load(h.icon, item)
                    h.text.text = if (item.key in store.hidden) "${item.label}  ·  hidden" else item.label
                    h.row.setOnClickListener { closeSearch(); launch(item, h.icon) }
                    h.row.setOnLongClickListener { showMenu(item, h.icon); true }
                }
                is Web -> {
                    h.icon.tag = null
                    h.icon.setImageResource(android.R.drawable.ic_menu_search)
                    h.icon.setPadding(dp(11), dp(11), dp(11), dp(11))
                    h.icon.setColorFilter(WHITE)
                    h.text.text = "Search web for \u201C${item.q}\u201D"
                    h.row.setOnClickListener { closeSearch(); web(item.q) }
                }
                is Section -> {
                    h.icon.visibility = View.GONE
                    h.text.text = item.title
                    h.text.textSize = 13f
                    h.text.typeface = Typeface.DEFAULT_BOLD
                    h.text.setTextColor(0x99FFFFFF.toInt())
                }
            }
        }
    }
}
