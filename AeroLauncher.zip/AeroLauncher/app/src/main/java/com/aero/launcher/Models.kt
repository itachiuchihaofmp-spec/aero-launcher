package com.aero.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.util.concurrent.Executors

data class App(val label: String, val pkg: String, val cls: String, val category: Int) {
    val key: String get() = "$pkg/$cls"
    val component: ComponentName get() = ComponentName(pkg, cls)
}

object Header
data class Web(val q: String)
data class Section(val title: String)

/** Tiny SharedPreferences wrapper: dock, hidden apps, launch counts (for Suggestions). */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("aero", Context.MODE_PRIVATE)

    val hasDock: Boolean get() = sp.contains("dock")

    var dock: List<String>
        get() = sp.getString("dock", "")!!.split("|").filter { it.isNotEmpty() }
        set(v) = sp.edit().putString("dock", v.joinToString("|")).apply()

    var hidden: Set<String>
        get() = sp.getStringSet("hidden", emptySet())!!.toSet()
        set(v) = sp.edit().putStringSet("hidden", v).apply()

    fun bump(key: String) {
        sp.edit().putInt("n:$key", (sp.getInt("n:$key", 0)) + 1).apply()
    }

    fun counts(): Map<String, Int> =
        sp.all.entries
            .filter { it.key.startsWith("n:") }
            .associate { it.key.substring(2) to ((it.value as? Int) ?: 0) }
}

/**
 * Renders each icon ONCE (off the main thread) into a ready-made rounded bitmap and keeps it in
 * an LruCache. Scrolling/paging then only blits bitmaps = butter smooth even on Helio P70.
 */
object IconLoader {
    var px = 128
    private val cache = object : LruCache<String, Bitmap>(14 shl 20) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun load(iv: ImageView, app: App) {
        iv.tag = app.key
        val hit = cache.get(app.key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        val ctx = iv.context.applicationContext
        pool.execute {
            val bmp = render(ctx, app)
            main.post { if (iv.tag == app.key) iv.setImageBitmap(bmp) }
        }
    }

    fun warm(ctx: Context, list: List<App>) {
        val c = ctx.applicationContext
        pool.execute { list.forEach { render(c, it) } }
    }

    private fun render(ctx: Context, app: App): Bitmap {
        cache.get(app.key)?.let { return it }
        val s = px
        val raw = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(raw)
        val pm = ctx.packageManager
        val d = try {
            pm.getActivityIcon(app.component)
        } catch (e: Exception) {
            pm.defaultActivityIcon
        }
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            // Draw the raw layers full-bleed so OEM masks (circle etc.) don't apply
            val o = (s * 0.25f).toInt()
            for (layer in listOf(d.background, d.foreground)) {
                layer?.setBounds(-o, -o, s + o, s + o)
                layer?.draw(c)
            }
        } else {
            c.drawColor(Color.WHITE)
            val p = (s * 0.14f).toInt()
            d.setBounds(p, p, s - p, s - p)
            d.draw(c)
        }
        // iOS-style rounded square, anti-aliased via shader
        val out = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val r = s * 0.225f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = BitmapShader(raw, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        Canvas(out).drawRoundRect(RectF(0f, 0f, s.toFloat(), s.toFloat()), r, r, paint)
        raw.recycle()
        cache.put(app.key, out)
        return out
    }
}
